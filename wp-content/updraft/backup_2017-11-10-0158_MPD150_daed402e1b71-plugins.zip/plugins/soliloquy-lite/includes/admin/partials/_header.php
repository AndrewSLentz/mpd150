<?php $base = Soliloquy_Lite::get_instance(); ?>
<div id="soliloquy-header">

	<div id="soliloquy-logo"><img src="<?php echo plugins_url( 'assets/images/soliloquy-logo.png', $base->file  ); ?>" alt="<?php _e( 'Soliloquy', 'soliloquy'); ?>"></div>

</div>