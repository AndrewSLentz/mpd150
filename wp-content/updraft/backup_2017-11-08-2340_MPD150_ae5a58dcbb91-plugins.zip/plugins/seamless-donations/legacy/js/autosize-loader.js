jQuery( document ).ready( function() {
	jQuery( 'textarea' ).autosize();
} );
