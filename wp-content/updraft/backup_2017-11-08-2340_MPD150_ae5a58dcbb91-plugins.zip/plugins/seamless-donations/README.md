# seamless-donations
The Most Popular Donations Plugin for WordPress

Pull Requests Welcome
=====================

Got a fix for a bug? Have a feature to add? Submit a Pull Request and I'll take a look!

